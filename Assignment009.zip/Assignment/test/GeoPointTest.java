package cp120.assignments.geo_shape;

import java.awt.Point;
import java.awt.geom.Point2D;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class GeoPointTest {

	static GeoPoint geoPoint;

	@BeforeClass
	public static void setup() {
		geoPoint = new GeoPoint(5.5f, 8.5f);
	}

	@Test
	public void testDistance() {
		GeoPoint otherGeoPoint = new GeoPoint(4.5f, 7.5f);

		float actualDistance = geoPoint.distance(otherGeoPoint);
		float expectedDistance = (float) Math.sqrt(Math.pow(geoPoint.getXco()
				- otherGeoPoint.getXco(), 2)
				+ Math.pow(geoPoint.getYco() - otherGeoPoint.getYco(), 2));

		Assert.assertEquals(expectedDistance, actualDistance, 0.0f);
	}

	@Test
	public void testGetIntPoint() {

		Point actualPoint = geoPoint.getIntPoint();

		Assert.assertEquals(Math.round(geoPoint.getXco()), actualPoint.getX(),
				0.0);
		Assert.assertEquals(Math.round(geoPoint.getYco()), actualPoint.getY(),
				0.0);
	}

	@Test
	public void testGetPoint2D() {
		Point2D actualpoint2d = geoPoint.getPoint2D();

		Assert.assertEquals(geoPoint.getXco(), actualpoint2d.getX(), 0.0f);
		Assert.assertEquals(geoPoint.getYco(), actualpoint2d.getY(), 0.0f);
	}

	@Test
	public void testGetXco() {
		float actualXCo = geoPoint.getXco();
		Assert.assertEquals(5.5f, actualXCo, 0.0f);
	}

	@Test
	public void testGetYco() {
		float actualYCo = geoPoint.getYco();
		Assert.assertEquals(8.5f, actualYCo, 0.0f);
	}

	@Test
	public void testToString() {
		String actualToString = geoPoint.toString();
		String expectedToString = "(" + geoPoint.getXco() + ","
				+ geoPoint.getYco() + ")";
		Assert.assertEquals(expectedToString, actualToString);
	}
}