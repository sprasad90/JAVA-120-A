package cp120.assignments.geo_shape;

import static org.junit.Assert.assertEquals;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class GeoLineTest {

	static GeoLine test;
	static GeoPoint start;
	static GeoPoint end;

	@BeforeClass
	public static void setup() {
		start = new GeoPoint(10.5f, 5.5f);
		end = new GeoPoint(8.5f, 3.5f);
		test = new GeoLine(start,Color.BLACK, end);
	}

	@Test
	public void testGetStart() {
		GeoPoint result = test.getStart();

		assertEquals(start.getXco(), result.getXco(), 0.0f);
		assertEquals(start.getYco(), result.getYco(), 0.0f);
	}

	@Test
	public void testGetEnd() {
		GeoPoint result = test.getEnd();

		assertEquals(end.getXco(), result.getXco(), 0.0f);
		assertEquals(end.getYco(), result.getYco(), 0.0f);
	}

	@Test
	public void testlength() {
		double result = test.length();
		double expectedValue = start.distance(end);
		assertEquals(expectedValue, result, 0.0);

	}

	@Test
	public void testslope() {
		double result = test.slope();
		double expectedValue = (end.getYco() - start.getYco())
				/ (end.getXco() - start.getXco());
		;
		assertEquals(expectedValue, result, 0.0);

	}

	@Test
	public void testDraw() {
		BufferedImage image = new BufferedImage(2, 5,
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D graphics2D = image.createGraphics();
		test.draw(graphics2D);
		assertEquals(Color.BLUE,graphics2D.getColor());
	}

	@Test
	public void testToString() {
		String actualToString = test.toString();
		String expectedToString = "origin="
				+ test.getStart()
				+ ",color="
				+ String.format("#%02x%02x%02x", test.getColor().getRed(), test
						.getColor().getGreen(), test.getColor().getBlue())
				+ "end=" + test.getEnd();
		Assert.assertEquals(expectedToString, actualToString);
	}
}