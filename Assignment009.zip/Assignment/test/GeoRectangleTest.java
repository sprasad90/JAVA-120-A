package cp120.assignments.geo_shape;

import static org.junit.Assert.assertEquals;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import org.junit.BeforeClass;
import org.junit.Test;

public class GeoRectangleTest {

	static GeoRectangle geoRectangle;
	static GeoPoint origin;

	@BeforeClass
	public static void setup() {
		origin = new GeoPoint(10.5f, 5.5f);
		geoRectangle = new GeoRectangle(origin, Color.BLACK, 20.5, 30.5);
	}

	@Test
	public void testGetArea() {
		double actualArea = geoRectangle.area();
		double expectedArea = geoRectangle.getWidth()
				* geoRectangle.getHeight();
		assertEquals(expectedArea, actualArea, 0.0f);
	}

	@Test
	public void testDraw() {
		BufferedImage image = new BufferedImage(2, 5,
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D graphics2D = image.createGraphics();
		geoRectangle.draw(graphics2D);
		assertEquals(Color.BLUE,graphics2D.getColor());
	}

	@Test
	public void testGetColor() {
		assertEquals(Color.BLACK, geoRectangle.getColor());
	}

	@Test
	public void testGetEdgeColor() {
		assertEquals(Color.BLUE, geoRectangle.getEdgeColor());
	}

	@Test
	public void testGetEdgeWidth() {
		assertEquals(1, geoRectangle.getEdgeWidth(), 0.0f);
	}

	@Test
	public void testGetHeight() {
		assertEquals(30.5, geoRectangle.getHeight(), 0.0);
	}

	@Test
	public void testGetOrigin() {
		GeoPoint actualOrigin = geoRectangle.getOrigin();
		assertEquals(10.5f, actualOrigin.getXco(), 0.0f);
		assertEquals(5.5f, actualOrigin.getYco(), 0.0f);
	}

	@Test
	public void testGetWidth() {
		assertEquals(20.5, geoRectangle.getWidth(), 0.0);
	}

	@Test
	public void testGetPerimeter() {
		double actualPerimeter = geoRectangle.perimeter();
		double expectedPerimeter = (2 * (geoRectangle.getWidth() + geoRectangle
				.getHeight()));
		assertEquals(expectedPerimeter, actualPerimeter, 0.0);
	}

	@Test
	public void testToString() {
		Color c = geoRectangle.getColor();
		Color edgeC = geoRectangle.getEdgeColor();
		String expectedString = "origin=("
				+ geoRectangle.getOrigin().getXco()
				+ ","
				+ geoRectangle.getOrigin().getYco()
				+ "),color="
				+ String.format("#%02x%02x%02x", c.getRed(), c.getGreen(),
						c.getBlue())
				+ ",edgeColor="
				+ String.format("#%02x%02x%02x", edgeC.getRed(),
						edgeC.getGreen(), edgeC.getBlue()) + ",edgeWidth="
				+ geoRectangle.getEdgeWidth() + ",width="
				+ geoRectangle.getWidth() + ",height="
				+ geoRectangle.getHeight();
		assertEquals(expectedString, geoRectangle.toString());
	}
}