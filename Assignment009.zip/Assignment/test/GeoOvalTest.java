package cp120.assignments.geo_shape;

import static org.junit.Assert.assertEquals;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class GeoOvalTest {

	static GeoOval geoOval;
	static GeoPoint origin;

	@BeforeClass
	public static void setup() {
		origin = new GeoPoint(10.5f, 5.5f);
		geoOval = new GeoOval(origin, 20.5, 30.5);
	}

	@Test
	public void testDraw() {
		BufferedImage image = new BufferedImage(2, 5,
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D graphics2D = image.createGraphics();
		geoOval.draw(graphics2D);
		assertEquals(Color.BLUE,graphics2D.getColor());
	}

	@Test
	public void testPerimeter() {
		double actualPerimeter = geoOval.perimeter();
		double expectedPerimeter = Math.PI
				* 2
				* Math.sqrt(Math.pow(geoOval.getHeight() / 2, 2)
						+ Math.pow(geoOval.getWidth() / 2, 2));
		Assert.assertEquals(expectedPerimeter, actualPerimeter, 0.0);
	}

	@Test
	public void testArea() {
		double actualArea = geoOval.area();
		double expectedArea = Math.PI * geoOval.getWidth() / 2
				* geoOval.getHeight() / 2;
		Assert.assertEquals(expectedArea, actualArea, 0.0);
	}
}