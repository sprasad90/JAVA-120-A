package cp120.assignments.geo_shape;

import java.awt.Point;
import java.awt.geom.Point2D;

/**
 * This class encapsulates a point in a plane: (xco, yco)
 * This plane is very similar to the Cartesian plane, 
 * but the origin of the plane is its  upper left-hand corner 
 * and y-values increase as you move downwards
 *  @author sprasad
 */
public class GeoPoint {

	/**
	 * y-coordinate value
	 * @param
	 */
	private float xco;

	/**
	 * y-coordinate value
	 * @param
	 */
	private float yco;

	/**
	 * the getter for the encapsulated x-coordinate.
	 * @return x-coordinate
	 */
	public float getXco() {
		return xco;
	}

	/**
	 * setter for the encapsulated x-coordinate
	 * 
	 * @param xco
	 * 	 x-coordinate
	 */
	public void setXco(float xco) {
		this.xco = xco;
	}

	/**
	 * getter for the encapsulated y-coordinate
	 * 
	 * @return y-coordinate
	 */
	public float getYco() {
		return yco;
	}

	/**
	 * setter for the encapsulated y-coordinate
	 * 
	 * @param yco
	 *   y-coordinate
	 */
	public void setYco(float yco) {
		this.yco = yco;
	}

	/**
	 * This method will convert the encapsulated coordinates to type int; it
	 * does so by rounding the decimal values to the nearest integer. The
	 * converted coordinates will be stored in an instance of java.awt.Point;
	 * the Point object is returned.
	 * 
	 * @return Point object
	 */
	public Point getIntPoint() {
		int a = (int) Math.round(getXco());
		int b = (int) Math.round(getYco());
		return new Point(a, b);
	}

	/**
	 * calculates the distance between itself and another GeoPoint
	 * 
	 * @param other
	 *            other GeoPoint
	 * @return distance
	 */
	public float distance(GeoPoint other) {
		float x = (float) Math.pow(xco - other.xco, 2);
		float y = (float) Math.pow(yco - other.yco, 2);
		float dist = (float) Math.sqrt(x + y);
		return dist;

	}

	/**
	 * This method overrides the toString method in the superclass. It returns a
	 * string in the format (xco,yco)
	 * 
	 * for example, if the x-coordinate is 10.02 and the y-coordinate is 10.03,
	 * The follow string is returned: (10.02,10.03)
	 * 
	 * @return string in the format (xco,yco)
	 */
	public String toString() {
		return "(" + xco + "," + yco + ")";
	}

	/**
	 * Add the following constructor: public GeoPoint( float xco, float yco )
	 * Use this constructor to initialize the object's xco and yco fields.
	 * 
	 * @param Initialize
	 *            Object's xco and yco fields
	 **/
	public GeoPoint(float xco, float yco) {
		this.xco = xco;
		this.yco = yco;
	}

	
	/**
	 * This method will convert "this" GeoPoint object to an object of type Point2D. 
	 * It will then return the Point2D object. The code for the method is shown below; 
	 * it assumes that the x- and y-coordinates of the GeoPoint are stored in fields named xco and yco.
	 * 
	 * @param Initialize
	 *            Object's xco and yco fields
	 **/
	public Point2D getPoint2D()
	{
	    Point2D.Float point = new Point2D.Float( xco, yco );
	    return point;
	}
	
	
	
}
