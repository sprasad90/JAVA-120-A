package cp120.assignments.geo_shape;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Stroke;
/**
 * This class will serve as the superclass for other classes in this exercise.
 * It should contains fields for storing a shape-origin of type GeoPoint and a
 * color.
 * 
 * @author sprasad
 **/

public abstract class GeoShape {

	protected Color color;
	protected GeoPoint origin;

	/**
	 * @param Default
	 *            Origin
	 **/
	public static final GeoPoint DEFAULT_ORIGIN = new GeoPoint(0f, 0f);

	/**
	 * @param Default
	 *            Color
	 **/
	public static final Color DEFAULT_COLOR = Color.BLUE;

	/**
	 * @param Default
	 *            Color
	 **/
	public static final Color DEFAULT_EDGE_COLOR = Color.BLUE;

	/**
	 * @param Default
	 *            Width
	 **/
	public static final float DEFAULT_EDGE_WIDTH = 1;

	private float edgeWidth = DEFAULT_EDGE_WIDTH;
	private Color edgeColor = DEFAULT_EDGE_COLOR;

	/**
	 * setter for the encapsulated color
	 * 
	 * @param color
	 *            encapsulated color
	 */
	public void setEdgeColor(Color color) {
		this.edgeColor = color;
	}

	/**
	 * getter for the encapsulated color
	 * 
	 * @param color
	 *            encapsulated color
	 */
	public Color getEdgeColor() {
		return edgeColor;
	}

	/**
	 * setter for the encapsulated Width
	 * 
	 * @param Width
	 *            encapsulated Width
	 */

	public void setEdgeWidth(float edgeWidth) {
		this.edgeWidth = edgeWidth;
	}

	/**
	 * getter for the encapsulated Width
	 * 
	 * @param width
	 *            encapsulated width
	 */
	public float getEdgeWidth() {
		return edgeWidth;
	}

	/**
	 * getter for the encapsulated Width
	 * 
	 * @param width
	 *            encapsulated width
	 */
	public void setEdge(Color color, float width) {
		setEdgeColor(color);
		setEdgeWidth(width);
	}

	/**
	 * Default Constructor
	 **/
	public GeoShape() {
		this(DEFAULT_ORIGIN, DEFAULT_COLOR);
	}

	/**
	 * Use this constructor to initialize the object's origin and color fields.
	 * 
	 **/
	public GeoShape(GeoPoint origin, Color color) {
		this.origin = origin;
		this.color = color;

	}

	/**
	 * This method method must be implemented by every concrete subclass of
	 * GeoShape.
	 * 
	 * @param gtx
	 */

	public abstract void draw(Graphics2D gtx);

	/**
	 * getter for the encapsulated origin
	 * 
	 * @return encapsulated origin
	 */
	public GeoPoint getOrigin() {
		return origin;
	}

	/**
	 * converts the encapsulated coordinates to integers, and stores them in an
	 * object of type java.awt.Point; the Point object is returned. The
	 * conversion must round the decimal values to integer values
	 * 
	 * @return Point object
	 */
	public Point getIntOrigin() {
		int a = (int) Math.round(origin.getXco());
		int b = (int) Math.round(origin.getYco());
		return new Point(a, b);
	}

	/**
	 * setter for the encapsulated origin
	 * 
	 * @param origin
	 *            encapsulated origin
	 */
	public void setOrigin(GeoPoint origin) {
		this.origin = origin;
	}

	/**
	 * setter for the encapsulated color
	 * 
	 * @param color
	 *            encapsulated color
	 */
	public void setColor(Color color) {
		this.color = color;
	}

	/**
	 * getter for the encapsulated color
	 * 
	 * @return encapsulated color
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * overrides Object.toString. It returns a string in the format
	 * origin=(xco,yco),color=#cccccc. For example, given a GeoShape with origin
	 * at (7.7,8.8) and a color of magenta, the follow string is returned:
	 * origin=(7.7,8.8),color=#ff00ff
	 * 
	 * Revise the toString() method to include the new properties; the string
	 * you return should be similar to this one:
	 * 
	 * 
	 * @return string in format
	 *         origin=(10.02,10.03),color=#ffff00,edgeColor=#ffff00
	 *         ,edgeWidth=2.1
	 */
	public String toString() {
		int r1 = color.getRed();
		int g1 = color.getGreen();
		int b1 = color.getBlue();
		String hex1 = String.format("#%02x%02x%02x", r1, g1, b1);

		int r2 = edgeColor.getRed();
		int g2 = edgeColor.getGreen();
		int b2 = edgeColor.getBlue();

		String hex2 = String.format("#%02x%02x%02x", r2, g2, b2);

		return "origin=" + origin + ",color=" + hex1 + ",edgeColor=" + hex2
				+ ",edgeWidth=" + edgeWidth;
	}

/**
 * This method is distinct from draw( Graphics2D ); it is a convenience
 * method for use by GeoShape subclasses. This method will, as necessary,
 * fill a shape with the appropriate color and (as necessary) draw the edge
 * of the shape with appropriate width and color. It will employ gtx.fill(
 * Shape ) and gtx.draw( Shape ).
 * 
 */
public void draw(java.awt.Shape shape, Graphics2D gtx ) {
	//Shape shape = new Shape;
	if (getColor() != null) {
		gtx.setColor(getColor());
		gtx.fill(shape);
	}

	if (getEdgeColor() != null && getEdgeWidth() > 0) {
		gtx.setBackground(getEdgeColor());
		Stroke stroke = new BasicStroke(getEdgeWidth());
		gtx.setStroke(stroke);
		gtx.draw(shape);
	}
	}

}

