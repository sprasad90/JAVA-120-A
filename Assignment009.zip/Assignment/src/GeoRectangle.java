package cp120.assignments.geo_shape;

import java.awt.*;
import java.awt.geom.Rectangle2D;

/**
 * This class encapsulates a rectangle as defined by its upper left-hand corner,
 * width and height. Class has two fields of type double for storing the width
 * and the height
 * @author sprasad
 */
public class GeoRectangle extends GeoShape {

	protected double width;
	protected double height;
	
	/**
	 * constructor 
	 * @param origin
	 * @param width
	 * @param width
	 * @param height
	 **/
	public GeoRectangle() {
		super();
	}

	/**
	 * constructor 
	 * @param origin
	 * @param width
	 * @param height
	 **/
	public GeoRectangle(double width, double height) {
		this(DEFAULT_ORIGIN, DEFAULT_COLOR, width, height);
	}

	
	/**
	 * constructor 
	 * @param origin
	 * @param width
	 * @param height
	 **/
	public GeoRectangle(GeoPoint origin, double width, double height) {

		this(origin, DEFAULT_COLOR, width, height);
	}

	/**
	 * constructor 
	 * @param origin
	 * @param color
	 * @param width
	 * @param height
	 **/
	public GeoRectangle(GeoPoint origin, Color color, double width,
			double height) {
		this.origin = origin;
		this.color = color;
		this.width = width;
		this.height = height;
	}

	/**
	 * Returns the area of the rectangle.
	 * @return
	 **/
	public double area() {
		double area = (width * height);
		return area;
	}

	/**
	 * Returns the perimeter of the rectangle.
	 * @return
	 **/
	public double perimeter() {
		double perimeter = (2 * (width + height));
		return perimeter;
	}

	/**
	 * This is the setter for the encapsulated width
	 * 
	 * @param width
	 *            encapsulated width
	 */
	public void setWidth(double width) {
		this.width = width;
	}

	/**
	 * This is the getter for the encapsulated width.
	 * 
	 * @return encapsulated width.
	 */
	public double getWidth() {
		return width;
	}

	/**
	 * This is the setter for the encapsulated height
	 * 
	 * @param height
	 *            encapsulated height
	 */
	public void setHeight(double height) {
		this.height = height;
	}

	/**
	 * This is the getter for the encapsulated height.
	 * 
	 * @return encapsulated height.
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * This method overrides GeoShape.toString. It returns a string in the
	 * format origin=(xco,yco),color=#cccccc,width=width, height=height. For
	 * example, given a GeoRectangle with these properties:
	 * 
	 * xco = 7.7 yco = 8.8 color = green width = 6.6 height = 5.5 the follow
	 * string is returned:
	 * 
	 * origin=(7.7,8.8),color=#00ff00,width=6.6,height=5.5 See also
	 * GeoShape.toString.
	 * @return
	 */
	public String toString() {
		return super.toString() + ",width=" + width + ",height=" + height;
	}

	/**
	 * Modify the draw method so that it draws the rectangle in the plane: 
	 * Get the rectangle's origin and extract the x- and y-coordinates. 
	 * Use the x/y-coordinates, and the rectangle's width and height, to instantiate a
	 * new Rectangle2D.Double. 
	 * 
	 * Set the rectangle's color in the graphics context
	 * (the parameter, Graphics2D gtx); use gtx.setColor( Color ). Fill the
	 * rectangle, using gtx.fill( Shape ). 
	 * 
	 * If the edge color is not null, and the edge width is greater than 0
	 * Create a BasicStroke object, setting the width of the stroke to the edge width. Set the edge color in the
	 * graphics context; use gtx.setColor( Color ). 
	 * 
	 * Draw the edge, using gtx.draw( Shape ).
	 * @param gtx
	 **/
	public void draw(Graphics2D gtx) {
    	double x = getOrigin().getXco();
    	double y = getOrigin().getYco();
		Rectangle2D.Double shape = new Rectangle2D.Double(x, y, width, height);
		
		gtx.setColor(color);
		gtx.fill(shape);
		
    	if ( getEdgeColor() != null && getEdgeWidth() > 0 )
        {
            Stroke stroke  = new BasicStroke( getEdgeWidth() );
            gtx.setStroke( stroke );
            gtx.setColor( getEdgeColor());
            gtx.draw( shape );
        }    	
     }
}
 