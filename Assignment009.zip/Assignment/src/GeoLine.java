package cp120.assignments.geo_shape;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Line2D;

/**
 * GeoLine represents a line
 *@author sprasad
 */
public class GeoLine extends GeoShape {

	/**
	 * start point
	 * @param
	 */
	protected GeoPoint start;
	
	/**
	 * end point
	 * @param 
	 */
	protected GeoPoint end;

	/**
	 * Default constructor
	 * @param origin
	 * @param color
	 * @param end
	**/
	public GeoLine() {
		super();
	}

	/**
	 * Use these constructors to initialize the object's properties. The
	 * two-parameter constructor must chain to the three-parameter constructor,
	 * passing DEFAULT_COLOR for the color.
	 * constructor
	 * @param origin
	 * @param color
	 * @param end
	**/
	public GeoLine(GeoPoint origin, GeoPoint end) {
		this(origin, DEFAULT_COLOR, end);
	}

	/**
	 * constructor
	 * @param origin
	 * @param color
	 * @param end
	**/
	public GeoLine(GeoPoint origin, Color color, GeoPoint end) {
		this.start = origin;
		this.color = color;
		this.end = end;
	}

	/**
	 * Modify the draw method so that it draws the line in the plane:
	 * Get the x- and y-coordinates of the origin and the end point.
	 * Use the x/y-coordinates to instantiate a new Line2D.Double.
	 * Set the line's color in the graphics context.
	 * Use gtx.draw( Shape ) to draw the line.
	 * @param gtx  
	**/
	@Override
	public void draw ( Graphics2D gtx ) {
		
    	Line2D.Double shape = new Line2D.Double(start.getXco(), start.getYco(),
    			end.getXco(), end.getYco());
		
		gtx.setColor(color);
		gtx.fill(shape);
		
		if ( getEdgeColor() != null && getEdgeWidth() > 0 )
        {
            Stroke stroke  = new BasicStroke( getEdgeWidth() );
            gtx.setStroke( stroke );
            gtx.setColor( getEdgeColor());
            gtx.draw( shape );
        }    	
	}

	/**
	 * This is the getter for the first point (the origin).
	 * @return
	 **/
	public GeoPoint getStart() {
		return start;
	}

	/**
	 * This is the setter for the first point
	 * @param start
	 **/
	public void setStart(GeoPoint start) {
		this.start = start;
	}

	/**
	 * This is the getter for the second point.
	 * @return
	 **/
	public GeoPoint getEnd() {
		return end;
	}

	/**
	 * This is the setter for the second point.
	 * @param end
	 **/
	public void setEnd(GeoPoint end) {
		this.end = end;
	}

	/**
	 * public double length() Returns the length of the line (hint: use
	 * GeoPoint).
	 * @return
	 **/
	public double length(){		
		return start.distance(end);
	}

	/**
	 * public double slope(): 
	 * Returns the slope of the line. Given a line that
	 * passes through points (x, y) and (x1,y1), the formula for computing the 
	 * slope is as follows: frac{y_1\:-\:y}{x_1\:-\:x}
	 * @return
	 **/
	public double slope(){		
		return (end.getYco() - start.getYco()) / (end.getXco() - start.getXco()); 
	}

	/**
	 * This method overrides GeoShape.toString. 
	 * It returns a string in the format 
	 * origin=(xco,yco),color=#cccccc,end=(xco', yco'). 
	 * 
	 * For example, a red line with endpoints (5.1,6.2),(-3.7,-5.4) 
	 * will look like this:
	 * origin=(5.1,6.2),color=#ff0000,end=(-3.7,-5.4)
	 * @return 
	**/
	public String toString() {
		int r = color.getRed();
		int g = color.getGreen();
		int b = color.getBlue();

		String hex = String.format("#%02x%02x%02x", r, g, b);

		System.out.println ("start + hex +  end");
		return "origin=" + start + ",color=" + hex + "end=" + end;
		
	}

}
