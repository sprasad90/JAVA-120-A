package cp120.assignments.geo_shape;
import java.awt.Color;
import java.awt.Shape;

/**
 * This class encapsulates an oval shape. Note that, in graphics, an oval is
 * typically represented by a bounding rectangle; the upper left-hand corner of
 * the rectangle is the origin, and the width and height define the major and
 * minor axes. A circle is an oval in which the width and the height are the
 * same.
 * @author sprasad
 */
public class GeoOval extends GeoRectangle {
    
	/**
	 * constructor 
	 * @param width
	 * @param height
	 */
	public GeoOval(double width, double height){
		super (DEFAULT_ORIGIN, DEFAULT_COLOR, width, height);	
	}

	/**
	 * constructor
	 * @param origin
	 * @param width
	 * @param height
	 */
	public GeoOval( GeoPoint origin, double width, double height ){
		super (origin, DEFAULT_COLOR, width, height);
	}
	
	/**
	 * constructor
	 * @param origin
	 * @param color
	 * @param width
	 * @param height
	 */
	public GeoOval( GeoPoint origin, Color color, double width, double height ){
		super.origin = origin;
		super.color = color;
		super.width = width;
		super.height = height;		
	}

	/**
     * This method is required to be implemented by every subclass of GeoShape. 
     * For now, it simply prints 
     * Drawing oval: followed by a single space and the object itself. 
     * 
     * For example, if an oval has an origin of (9.9,10.01), a width of 6.6, 
     * a height of 5.5, and a color of magenta, 
     * this method will print:
     * Drawing oval: origin=(9.9,10.01),color=#00ffff,width=6.6,height=5.5
     * See also GeoRectangle.toString().
     * 
     * @param gtx 
     */
	public void draw( Shape Graphics2D ) {
		System.out.println("Drawing oval: " + toString());
    }
	
	/**	
	 * public double perimeter(): 
	 * Returns an approximation of the perimeter of an oval. 
	 * To calculate it you must use the specific formula given below.
	 * To approximate the perimeter of an oval use the equation:
	 * perimeter\:=\:2\pi\sqrt{\frac{a^2\:+\:b^2}{2}}
	 * @return
	 **/	
	
	public double perimeter(){
		double a = Math.pow(this.height/2, 2);
		double b = Math.pow(this.width/2, 2);
		double c= a + b;
		double d = Math.sqrt (c);
		double e =  Math.PI * 2 * d;
		
		return e;
				
	}

	/**	
	 * public double area(): 
	 * Returns the approximate area of the oval; use the formula given below.
	 * 	To approximate the area of an oval use the equation:
	 * 	area\:=\:ab\pi
	 * @return
	 **/	
	public double area(){
	
		double f =  Math.PI * this.width/2 * this.height/2;	
		return f;
				
	}
}
