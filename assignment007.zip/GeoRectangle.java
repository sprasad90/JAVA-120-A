package cp120.assignments.geo_shape;

import java.awt.*;

/**
 * This class encapsulates a rectangle as defined by its upper left-hand corner,
 * width and height. Class has two fields of type double for storing the width
 * and the height
 */
public class GeoRectangle extends GeoShape {

    protected static  double width;
    protected static  double height;
/*    private Color color;
    private GeoPoint origin;*/

    /**
     * This method is required to be implemented by every subclass of GeoShape. 
     * For now, it simply prints Drawing rectangle: followed by a single space 
     * and the object itself. 
     * 
     * For example, if a rectangle has an origin of (10.02,10.03), 
     * a width of 6.6, a height of 5.5, and a color of yellow, 
     * this method will print:
     * Drawing rectangle: origin=(10.02,10.03),color=#ffff00,width=6.6,height=5.5
     * See also GeoShape.toString()
     * 
     * @param gtx 
     * @return 
     */

    /*public void GeoShape( GeoPoint origin, Color color ){    
    super.origin = origin;
    super.color = color;
    }
    */    
    public GeoRectangle(){
    	super();
    	//this( DEFAULT_ORIGIN, DEFAULT_COLOR, width, height );
    }
   
    public GeoRectangle( double width, double height ){
        //this();
    	this( DEFAULT_ORIGIN, DEFAULT_COLOR, width, height );
    }
   
    public GeoRectangle( GeoPoint origin, double width, double height ){
    
    	this( origin, DEFAULT_COLOR, width, height );
    	//this (width, height);
    }
    
    public GeoRectangle( GeoPoint origin, Color color, double width, double height )
    {
    	 this.origin = origin;
    	 this.color =  color;
    	 this.width =  width;
    	 this.height = height;
    }
    /**
    Returns the area of the rectangle.
    **/   
    public double area() {
    	double area = ( width * height );
    	return area;
    }
    
    /**
    Returns the perimeter of the rectangle.
    **/    
    public double perimeter(){
    	double perimeter = (2 * ( width + height ));
    	return perimeter;
    }
    
    
    /**
     * This is the setter for the encapsulated width
     * @param width encapsulated width    
     */
    public void setWidth(double width) {	
	this.width = width;
    }

    /**
     * This is the getter for the encapsulated width.
     * 
     * @return encapsulated width.
     */
    public double getWidth() {	
	return width;
    }

    /**
     * This is the setter for the encapsulated height
     *      
     * @param height encapsulated height
     */
    public void setHeight(double height) {	
	this.height = height;
    }

    /**
     * This is the getter for the encapsulated height.
     * 
     * @return encapsulated height.
     */
    public double getHeight() {	
	return height;
    }

    /**
     * This method overrides GeoShape.toString. 
     * It returns a string in the format origin=(xco,yco),color=#cccccc,width=width, height=height.
     * For example, given a GeoRectangle with these properties:
     * 
     * xco	 = 7.7
     * yco	 = 8.8
     * color	 = green
     * width	 = 6.6
     * height	 = 5.5
     * the follow string is returned:
     * 
     * origin=(7.7,8.8),color=#00ff00,width=6.6,height=5.5
     * See also GeoShape.toString.
    */
    public String toString() {
	return super.toString() + ",width=" + width + ",height=" + height;
    }

    public void draw(Graphics2D gtx) {
    	System.out.println("Drawing rectangle: " + toString() + ",width=" + width + ",height=" + height);
        }


   
}
