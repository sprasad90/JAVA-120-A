package cp120.assignments.geo_shape;

import java.awt.Color;
import java.awt.Graphics2D;

public class GeoLine extends GeoShape {

protected  GeoPoint start;
protected  GeoPoint end;
	/**
	Default constructor
	 **/
	public GeoLine (){
		super();
	}
	
	/** Use these constructors to initialize the object's properties. 
	The two-parameter constructor must chain to the three-parameter constructor, 
	passing DEFAULT_COLOR for the color.
	 **/	
	public GeoLine( GeoPoint origin, GeoPoint end ){
		this(origin, DEFAULT_COLOR, end);
	}
	
		
	public GeoLine( GeoPoint origin, Color color, GeoPoint end ){
		this.start = origin;
		this.color = color;
		this.end = end;
	}
	
    /**  public void draw( Graphics2D gtx )
    This method is required to be implemented by every subclass of GeoShape. For now, it simply prints Drawing line:followed by a single space and the object itself. For example, if a line is defined by the points (10.02,10.03), (-5, -7.2) and a color of cyan, this method will print:
    Drawing line: origin=(10.02,10.03),color=#00ffff,end=(-5.0,-7.2)
     **/
    
    @Override
	public void draw(Graphics2D gtx) {
		System.out.print("Drawing line: " + super.toString());
	}

	/**
	 *
	This is the getter for the first point (the origin).
	 **/	
	public GeoPoint getStart(){
		return start;
	}
	
	/**
	This is the setter for the first point 
	 **/	
	public void setStart( GeoPoint start ){
		this.start = start;
	}
	 
	/**
	This is the getter for the second point.
	 **/	
	public GeoPoint getEnd() {
		return end;
	}
		
	/**
	This is the setter for the second point.
	 **/	
	public void setEnd( GeoPoint end ) {
		this.end = end;
	}
	
	/**
	This method overrides GeoShape.toString. It returns a string in the format origin=(xco,yco),color=#cccccc,end=(xco', yco'). For example, a red line with endpoints (5.1,6.2),(-3.7,-5.4) will look like this:
	origin=(5.1,6.2),color=#ff0000,end=(-3.7,-5.4)
	 **/	
	public String toString(){
		int r = color.getRed();
		int g = color.getGreen();
		int b = color.getBlue();
		
		String hex = String.format("#%02x%02x%02x", r, g, b);
		
		return "origin=" + start + ",color=" + hex + "end=" + end  ;	
	}
	
	
}
