package cp120.assignments.geo_shape;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;

/**
 * This class will serve as the superclass for other classes in this exercise. 
 * It should contains fields for storing a shape-origin of type GeoPoint and a color. 
 * 
 */

public abstract class GeoShape {

    protected  Color color;
    protected  GeoPoint origin;
		
    public static final GeoPoint DEFAULT_ORIGIN = new GeoPoint( 0f, 0f );    
    public static final Color DEFAULT_COLOR = Color.BLUE;
    
    /**
    Default Constructor
    **/
    public GeoShape(){    
    	this (DEFAULT_ORIGIN, DEFAULT_COLOR);
    }

    /**
    Use this constructor to initialize the object's origin and color fields.
    **/
    public GeoShape( GeoPoint origin, Color color ){    
    this.origin = origin;
    this.color = color;
    
    }
    
    /**
     * This method method must be implemented by every concrete subclass of GeoShape.
     * @param gtx 
     */
                
    public abstract void draw(Graphics2D gtx);
   
    /**
     * getter for the encapsulated origin
     * @return encapsulated origin
     */
    public GeoPoint getOrigin() {
	return origin;
    }

    /**
     * converts the encapsulated coordinates to integers, 
     * and stores them in an object of type java.awt.Point;
     * the Point object is returned. The conversion must round the decimal values to integer values
     * 
     * @return Point object
     */
    public Point getIntOrigin() {
	int a = (int) Math.round(origin.getXco());
	int b = (int) Math.round(origin.getYco());
	return new Point(a, b);
    }

    /**
     * setter for the encapsulated origin
     * 
     * @param origin encapsulated origin
     */
    public void setOrigin(GeoPoint origin) {
	this.origin = origin;
    }

    /**
     * setter for the encapsulated color
     * 
     * @param color encapsulated color
     */
    public void setColor(Color color) {
	this.color = color;
    }

    /**
     * getter for the encapsulated color
     * 
     * @return   encapsulated color
     */
    public Color getColor() {
	return color;
    }

    /**
     * overrides Object.toString. It returns a string in the format origin=(xco,yco),color=#cccccc. 
     * For example, given a GeoShape with origin at (7.7,8.8) and a color of magenta, the follow string is returned:
     * origin=(7.7,8.8),color=#ff00ff
     * 
     * @return string in format origin=(xco,yco),color=#cccccc
     */
    public String toString() {
	int r = color.getRed();
	int g = color.getGreen();
	int b = color.getBlue();
	
	String hex = String.format("#%02x%02x%02x", r, g, b);
	
	return "origin=" + origin + ",color=" + hex;
    }

}
