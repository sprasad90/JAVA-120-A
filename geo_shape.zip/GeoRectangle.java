package cp120.assignments.geo_shape;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

/**
 * This class encapsulates the parameters needed to draw a rectangle
 * in a GeoPlane.
 * 
 * @author jack
 *
 * @see GeoPlane
 */
public class GeoRectangle extends GeoShape
{
    private double  width;
    private double  height;
    
    /**
     * Constructor; sets the width and height of the rectangle.
     * 
     * @param width     The width of the rectangle.
     * @param height    The height of the bounding box that defines
     *                  the rectangle.
     */
    public GeoRectangle( double width, double height )
    {
        this( DEFAULT_ORIGIN, DEFAULT_COLOR, width, height );
    }
    
    /**
     * Constructor; sets the origin, width and height of the rectangle.
     * 
     * @param origin    Contains the (x,y) coordinates of the upper-left-hand 
     *                  corner of the bounding box that defines the oval.
     * @param width     The width the bounding box that defines of the oval.
     * @param height    The height of the bounding box that defines the oval.
     */
    public GeoRectangle( GeoPoint origin, double width, double height )
    {
        this( origin, DEFAULT_COLOR, width, height );
    }
    
    /**
     * Constructor; sets the origin, width and height of the rectangle.
     * 
     * @param origin    Contains the (x,y) coordinates of the upper-left-hand
     *                  corner of the rectangle.
     * @param width     The width of the rectangle.
     * @param color     The color of the rectangle.
     * @param height    The height of the rectangle
     */
    public
    GeoRectangle( GeoPoint origin, Color color, double width, double height )
    {
        super( origin, color );
        this.width = width;
        this.height = height;
    }
    
    /**
     * Sets the width of the rectangle.
     * @param width The width of the rectangle.
     */
    public void setWidth( double width )
    {
        this.width = width;
    }
    
    /** 
     * Returns the width of the rectangle.
     * @return The width of the rectangle.
     */
    public double getWidth()
    {
        return width;
    }   
    
    /**
     * Sets the height of the rectangle.
     * @param height The height of the rectangle.
     */
    public void setHeight( double height )
    {
        this.height = height;
    }
    
    /** 
     * Returns the height of the rectangle.
     * @return The height of the rectangle.
     */
    public double getHeight()
    {
        return height;
    }
    
    /**
     * Draws the rectangle using the given graphics context.
     * 
     * @param gtx   The given graphics context.
     */
    public void draw( Graphics2D gtx )
    {
        System.out.println( "Drawing rectangle: " + toString()  );
        GeoPoint    origin  = getOrigin();
        double      xco     = origin.getXco();
        double      yco     = origin.getYco();
        Shape       shape   = new Rectangle2D.Double( xco, yco, width, height );
        gtx.setColor( getColor() );
        gtx.fill( shape );
        
        Color   edgeColor   = getEdgeColor();
        float   edgeWidth   = getEdgeWidth();
        if ( edgeColor != null && edgeWidth > 0 )
        {
            Stroke  stroke  = new BasicStroke( edgeWidth );
            gtx.setStroke( stroke );
            gtx.setColor( edgeColor);
            gtx.draw( shape );
        }
    }
    
    /**
     * Returns the area of the rectangle.
     * @return The area of the rectangle.
     */
    public double area()
    {
        double  area    = getWidth() * getHeight();
        return area;
    }
    
    /**
     * Returns the perimeter of the rectangle.
     * @return The perimeter of the rectangle.
     */
    public double perimeter()
    {
        double  peri    = 2 * getWidth() + 2 * getHeight();
        return peri;
    }

    /**
     * Returns a readable string representing the properties of this rectangle.
     * @return A readable string representing the properties of this rectangle.
     */
    public String toString()
    {
        StringBuilder   bldr    = new StringBuilder( super.toString() );
        bldr.append( ",width=" + width + ",height=" + height );
        return bldr.toString();
    }
}
