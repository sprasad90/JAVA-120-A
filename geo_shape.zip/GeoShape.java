package cp120.assignments.geo_shape;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;

/**
 * Abstract super class of any shape that can be drawn in a GeoPlane.
 * 
 * @see GeoPlane
 * 
 * @author jack
 */
public abstract class GeoShape
{
    /**
     * The default origin of a shape.
     */
    public static final GeoPoint    DEFAULT_ORIGIN      =
        new GeoPoint( 0f, 0f );
    
    /**
     * The default color of a shape.
     */
    public static final Color       DEFAULT_COLOR       = Color.BLUE;
    
    /**
     * The default edge color of a shape.
     */
    public static final Color       DEFAULT_EDGE_COLOR  = Color.BLUE;   
    
    /**
     * The default edge width of a shape.
     */
    public static final float       DEFAULT_EDGE_WIDTH  = 1;

    private GeoPoint    origin;
    private Color       color;
    private float       edgeWidth   = DEFAULT_EDGE_WIDTH;
    private Color       edgeColor   = DEFAULT_EDGE_COLOR;
    
    /**
     * Method to draw a shape in a GeoPlane window. Must be implemented
     * by all subclasses. The graphics context used for drawing is supplied
     * by the GeoPlane class.
     * 
     * @param gtx   Graphics context for drawing a shape.
     */
    public abstract void draw( Graphics2D gtx );
    
    /**
     * Constructor; sets the origin and color of a shape.
     * 
     * @param origin    The origin of the shape.
     * @param color     The color of the shape.
     */
    public GeoShape( GeoPoint origin, Color color )
    {
        this.origin = origin;
        this.color = color;
    }
    
    /**
     * Sets the origin of this shape.
     * 
     * @param origin The origin for this shape.
     */
    public void setOrigin( GeoPoint origin )
    {
        this.origin = origin;
    }
    
    /**
     * Returns the origin of this shape.
     * 
     * @return returns the origin of this shape.
     */
    public GeoPoint getOrigin()
    {
        return origin;
    }
    
    /**
     * Rounds the coordinates of the origin of this shape to the nearest
     * integer, and return the integer coordinates in a Point object.
     * 
     * @return The coordinates of the origin of this shape as integers.
     */
    public Point getIntOrigin()
    {
        return origin.getIntPoint();
    }
    
    /**
     * Sets the color of this shape.
     * 
     * @param color The color for this shape.
     */
    public void setColor( Color color )
    {
        this.color = color;
    }
    
    /**
     * Returns the color of this shape.
     * 
     * @return The color of this shape.
     */
    public Color getColor()
    {
        return color;
    }
    
    /**
     * Returns the edge color of this shape.
     * 
     * @return The edge color of this shape.
     */
    public Color getEdgeColor()
    {
        return edgeColor;
    }
    
    /**
     * Sets the edge color of this shape.
     * 
     * @param color The edge color for this shape.
     */
    public void setEdgeColor( Color color )
    {
        edgeColor = color;
    }
    
    /**
     * Sets the edge width of this shape.
     * 
     * @param width The edge width for this shape.
     */
    public void setEdgeWidth( float width )
    {
        edgeWidth = width;
    }
    
    /**
     * Returns the edge width of this shape.
     * 
     * @return The edge width of this shape.
     */
    public float getEdgeWidth()
    {
        return edgeWidth;
    }
    
    /**
     * Convenience method to set the edge color and edge width of this shape.
     * @param color The edge color for this shape.
     * @param width The edge width for this shape.
     */
    public void setEdge( Color color, float width )
    {
        edgeColor = color;
        edgeWidth = width;
    }
    
    /**
     * Returns a readable string representing the properties of this shape.
     * @return A readable string representing the properties of this shape.
     */
    public String toString()
    {
        String      red     = String.format( "%02x", color.getRed() );
        String      green   = String.format( "%02x", color.getGreen() );
        String      blue    = String.format( "%02x", color.getBlue() );
        
        String      eRed     = String.format( "%02x", edgeColor.getRed() );
        String      eGreen   = String.format( "%02x", edgeColor.getGreen() );
        String      eBlue    = String.format( "%02x", edgeColor.getBlue() );
        
        StringBuilder   bldr    = new StringBuilder();
        bldr.append( "origin=" ).append( origin );
        bldr.append( ",color=#" ).append( red ).append( green ).append( blue );
        bldr.append( ",edgeWidth=" ).append( edgeWidth );
        bldr.append( ",edgeColor=#" );
            bldr.append( eRed ).append( eGreen ).append( eBlue );
        
        return bldr.toString();
    }
}
// Complete