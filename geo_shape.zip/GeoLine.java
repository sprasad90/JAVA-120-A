package cp120.assignments.geo_shape;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;

/**
 * This class encapsulates the parameters needed to draw a line
 * in the GeoPlane window.
 * 
 * @see GeoPlane
 * 
 * @author jack
 */
public class GeoLine extends GeoShape
{
    private GeoPoint    end;
    
    /**
     *  Constructor to set the origin and end properties.
     *  
     * @param origin    The origin (start) of the line
     * @param end       The end of the line
     */
    public GeoLine( GeoPoint origin, GeoPoint end )
    {
        this( origin, DEFAULT_COLOR, end );
    }
    
    /**
     *  Constructor to set the origin, color and end properties.
     *  
     * @param origin    The origin (start) of the line
     * @param color     The color of the line
     * @param end       The end of the line
     */
    public
    GeoLine( GeoPoint origin, Color color, GeoPoint end )
    {
        super( origin, color );
        this.end = end;
    }
    
    /**
     * Draws the line using the given graphics context.
     * 
     * @param gtx   The given graphics context.
     */
    public void draw( Graphics2D gtx )
    {
        System.out.println( "Drawing line: " + this );
        GeoPoint    origin  = getOrigin();
        double      xco     = origin.getXco();
        double      yco     = origin.getYco();
        double      xco1    = end.getXco();
        double      yco1    = end.getYco();
        Line2D      shape   = 
            new Line2D.Double( xco, yco, xco1, yco1 );
        gtx.setColor( getColor() );
        gtx.draw( shape );
    }
    
    /**
     * Returns the starting point of the line.
     * @return The starting point of the line.
     */
    public GeoPoint getStart()
    {
        return getOrigin();
    }
    
    /**
     * Sets the starting point of the line.
     * @param start The starting point of the line.
     */
    public void setStart( GeoPoint start )
    {
        setOrigin( start );
    }
    
    /**
     * Returns the end point of the line.
     * @return The end point of the line.
     */
    public GeoPoint getEnd()
    {
        return end;
    }
    
    /**
     * Sets the end point of the line.
     * @param end The end point of the line.
     */
    public void setEnd( GeoPoint end )
    {
        this.end = end;
    }
    
    /**
     * Calculates the length of the line.
     * @return The length of the line.
     */
    public double length()
    {
        double   result  = getOrigin().distance( end );
        return result;
    }
    
    /**
     * Calculates the slope of the line.
     * @return The slope of the line.
     */
    public double slope()
    {
        GeoPoint    start   = getOrigin();
        float       numer   = end.getYco() - start.getYco();
        float       denom   = end.getXco() - start.getXco();
        float       slope   = numer / denom;
        return slope;
    }
    
    /**
     * Returns a readable string representing the properties of this line.
     * @return A readable string representing the properties of this line.
     */
    public String toString()
    {
        StringBuilder   bldr    = new StringBuilder();
        bldr.append( super.toString() ).append( ",end=" ).append( end );
        return bldr.toString();
    }
}
