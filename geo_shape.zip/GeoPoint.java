package cp120.assignments.geo_shape;

import java.awt.Point;

/**
 * This class represents the x- and y-coordinates of a point in the plane
 * of a window.
 * The origin of the coordinate system is the upper-left-hand corner of
 * the window. X-coordinates increase to the right, y-coordinates increase
 * as they move closer to the bottom of the window.
 * 
 * @author jack
 */
public class GeoPoint
{
    private float  xco;
    private float  yco;
    
    /**
     * Constructor; sets the x- and y-coordinates of the point.
     * @param xco   The x-coordinate of this point.
     * @param yco   The y-coordinate of this point.
     */
    public GeoPoint( float xco, float yco )
    {
        this.xco = xco;
        this.yco = yco;
    }
    
    /**
     * Returns the x-coordinate of the point.
     * @return The x-coordinate of the point.
     */
    public float getXco()
    {
        return xco;
    }
    
    /**
     * Sets the x-coordinate of this point.
     * @param xco The x-coordinate for this point.
     */
    public void setXco( float xco )
    {
        this.xco = xco;
    }
    
    /**
     * Returns the y-coordinate of the point.
     * @return The y-coordinate of the point.
     */
    public float getYco()
    {
        return yco;
    }
    
    /**
     * Sets the y-coordinate of this point.
     * @param yco The y-coordinate for this point.
     */
    public void setYco( float yco )
    {
        this.yco = yco;
    }
    
    /**
     * Returns a Point object representing the x- and y- coordinates as
     * integers. The integer values are computed from the actual values
     * by rounding.
     * @return A Point object representing the x- and y- coordinates as
     *         integers.
     */
    public Point getIntPoint()
    {
        int     xco     = (int)(this.xco + .5 );
        int     yco     = (int)(this.yco + .5 );
        Point   point   = new Point( xco, yco );
        return point;
    }
    
    /**
     * Computes the distance from this point to another point.
     * @param other The other point to which to calculate the distance.
     * @return The distance from this point to another point.
     */
    public float distance( GeoPoint other )
    {
        float   xDiff   = xco - other.xco;
        float   yDiff   = yco - other.yco;
        float   sum     = xDiff * xDiff + yDiff * yDiff;
        float   dist    = (float)Math.sqrt( sum );
        
        return dist;
    }
    
    /**
     * Returns a readable string representing the properties of this point.
     * @return A readable string representing the properties of this point.
     */
    public String toString()
    {
        StringBuilder   bldr    = new StringBuilder();
        bldr.append( "(" ).append( xco ).append( "," ).append( yco );
        bldr.append( ")" );
        return bldr.toString();
    }
}
