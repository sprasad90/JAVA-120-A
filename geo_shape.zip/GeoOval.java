package cp120.assignments.geo_shape;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * This class encapsulates the parameters needed to draw an oval
 * in a GeoPlane. The oval is represented by a bounding box.
 * 
 * @author jack
 *
 * @see GeoPlane
 */
public class GeoOval extends GeoRectangle
{
    /**
     * Constructor; sets the width and height of the oval.
     * 
     * @param width     The width of the bounding box that defines of the oval.
     * @param height    The height of the bounding box that defines the oval.
     */
    public GeoOval( double width, double height )
    {
        this( DEFAULT_ORIGIN, DEFAULT_COLOR, width, height );
    }
    
    /**
     * Constructor; sets the origin, width and height of the oval.
     * 
     * @param origin    Contains the (x,y) coordinates of the upper-left-hand 
     *                  corner of the bounding box that defines the oval.
     * @param width     The width of the bounding box that defines of the oval.
     * @param height    The height of the bounding box that defines the oval.
     */
    public GeoOval( GeoPoint origin, double width, double height )
    {
        this( origin, DEFAULT_COLOR, width, height );
    }
    
    /**
     * Constructor; sets the origin, color, width and height of the oval.
     * 
     * @param origin    Contains the (x,y) coordinates of the upper-left-hand 
     *                  corner of the bounding box that defines the oval.
     * @param color     The color of the oval.
     * @param width     The width the bounding box that defines of the oval.
     * @param height    The height of the bounding box that defines the oval.
     */
    public GeoOval( GeoPoint origin, Color color, double width, double height )
    {
        super( origin, color, width, height );
    }

    /**
     * Draws the oval using the given graphics context.
     * 
     * @param gtx   The given graphics context.
     */
    public void draw( Graphics2D gtx )
    {
        System.out.println( "Drawing oval: " + toString()  );
    }
    
    /**
     * Returns an approximation of the perimeter of the oval.
     * @return an approximation of the perimeter of the oval.
     */
    public double perimeter()
    {
        double  aRadius = getWidth() / 2;
        double  bRadius = getHeight() / 2;
        double  frac    = (aRadius * aRadius + bRadius * bRadius) / 2;
        double  result  = 2 * Math.PI * Math.sqrt( frac );
        
        return result;
    }
    
    /**
     * Returns the area of the oval.
     * @return The area of the oval.
     */
    public double area()
    {
        double  aRadius = getWidth() / 2;
        double  bRadius = getHeight() / 2;
        double  result  = Math.PI * aRadius * bRadius;
        
        return result;
    }
}
