package cp120.assignments.geo_shape;

import java.awt.Graphics2D;

/**
 * This class encapsulates an oval shape. Note that, in graphics, an oval is
 * typically represented by a bounding rectangle; the upper left-hand corner of
 * the rectangle is the origin, and the width and height define the major and
 * minor axes. A circle is an oval in which the width and the height are the
 * same.
 */
public class GeoOval extends GeoRectangle {

    /**
     * This method is required to be implemented by every subclass of GeoShape. 
     * For now, it simply prints Drawing oval: followed by a single space and the object itself. 
     * For example, if an oval has an origin of (9.9,10.01), a width of 6.6, 
     * a height of 5.5, and a color of magenta, this method will print:
     * Drawing oval: origin=(9.9,10.01),color=#00ffff,width=6.6,height=5.5
     * See also GeoRectangle.toString().
     * 
     * @param gtx 
     */
    public void draw(Graphics2D gtx) {
	System.out.print("Drawing oval: " + super.toString());
    }
}
