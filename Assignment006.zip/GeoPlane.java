package cp120.assignments.geo_shape;

import java.util.*;

/**
 * This is a simple class that contains an instance variable of type
 * List<GeoShape> with methods: add, remove, redraw
 */
public class GeoPlane {

    /**
     * list of shapes
     */
    private List<GeoShape> allShapes = new ArrayList<GeoShape>();

    /**
     * adds the given shape to the list
     * 
     * @param shape a shape
     */
    public void addShape(GeoShape shape) {
	allShapes.add(shape);
    }

    /**
     * removes the given shape from the list
     * 
     * @param shape a shape
     */
    public void removeShape(GeoShape shape) {
	allShapes.remove(shape);

    }

    /**
     * traverses the list, calling the draw method for each
     * GeoShape in the list. For its single argument use null; for example:
     * shape.draw(null)
     */
    public void redraw() {
	for (GeoShape shapes : allShapes) {
	    shapes.draw(null);
	}
    }
}
