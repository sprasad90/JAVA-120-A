package cp120.assignments.geo_shape;

import java.awt.Point;

/**
 * This class encapsulates a point in a plane: (xco, yco)
 * This plane is very similar to the Cartesian plane, 
 * but the origin of the plane is its  upper left-hand corner 
 * and y-values increase as you move downwards
 * 
 */
public class GeoPoint {

    /**
     * y-coordinate value
     */
    private float xco;
    
    /**
     * y-coordinate value
     */
    private float yco;

    /**
     * the getter for the encapsulated x-coordinate.
     * @return x-coordinate
     */
    public float getXco() {
	return xco;
    }

    /**
     * setter for the encapsulated x-coordinate
     * @param xco  x-coordinate
     */
    public void setXco(float xco) {
	this.xco = xco;
    }

    /**
     * getter for the encapsulated y-coordinate
     * @return y-coordinate
     */
    public float getYco() {
	return yco;
    }

    /**
     * setter for the encapsulated y-coordinate
     * @param yco y-coordinate
     */
    public void setYco(float yco) {
	this.yco = yco;
    }

    /**
     * This method will convert the encapsulated coordinates to type int; 
     * it does so by rounding the decimal values to the nearest integer. The
     * converted coordinates will be stored in an instance of
     * java.awt.Point; the Point object is returned.
     * 
     * @return  Point object
     */
    public Point getIntPoint() {
	int a = (int) Math.round(getXco());
	int b = (int) Math.round(getYco());
	return new Point(a, b);
    }

    /**
     * calculates the distance between itself and another GeoPoint
     * @param other other GeoPoint
     * @return distance
     */
    public float distance(GeoPoint other) {
	float x = (float) Math.pow(xco - other.xco, 2);
	float y = (float) Math.pow(yco - other.yco, 2);
	float dist = (float) Math.sqrt(x + y);
	return dist;

    }

    /**
    * This method overrides the toString method in the superclass. 
    * It returns a string in the format (xco,yco)
    * 
    * for example, if the x-coordinate is 10.02 and the y-coordinate is 10.03, 
    * The follow string is returned: (10.02,10.03)
    * 
    * @return  string in the format (xco,yco)
    */
    public String toString() {	
	return "(" + xco + "," + yco + ")";
    }
}
